import os
os.system("cls")

class Talabalar:
    def __init__(self,name,student_id):
        self.name = name 
        self.student_id  = student_id
        self.__grades = []

    def add_grade(self, new_grade):
        if 0 <= new_grade <= 100:
            self.__grades.append(new_grade)
        else:
            print("Xato baho!")

    def calculate_average(self):
        if len(self.__grades) == 0:
            return 0
        return sum(self.__grades) / len(self.__grades)
    
    def get_status(self):
        average = self.calculate_average()
        if 90 <= average <= 100:
            return "A'lo"
        elif 80 <= average < 90:
            return "Yaxshi"
        elif 70 <= average < 80:
            return "Qoniqarli"
        else:
            return "Qoniqarsiz"
        
t = Talabalar("Nodira", "S123")

t.add_grade(85)
t.add_grade(90)
print(t.calculate_average())
print(t.get_status())
t.add_grade(150)
