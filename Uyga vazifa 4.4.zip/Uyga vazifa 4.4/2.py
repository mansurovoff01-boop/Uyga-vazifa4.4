import os
os.system("cls")

class Employee:
    def __init__(self, name, employee_id, hourly_rate = 15):
        self.name = name
        self.employee_id = employee_id
        self.__working_hours = []
        self.hourly_rate = hourly_rate

    def log_hours(self,hour):
        if 0 <= hour <= 24:
            self.__working_hours.append(hour)
            return True
        return False
    def total_hours(self):
        return sum(self.__working_hours)
    def calculate_salary(self):
        return self.total_hours() * self.hourly_rate
    def reset_hours(self):
        self.__working_hours = []

e = Employee("Javlon", "E101", hourly_rate=20.0)
print(e.log_hours(8))   	
print(e.log_hours(9))   	
print(e.log_hours(10))  	
print(e.log_hours(25))

print(e.total_hours())       	
print(e.calculate_salary())  

e.reset_hours()
print(e.total_hours())       	
print(e.calculate_salary())
    