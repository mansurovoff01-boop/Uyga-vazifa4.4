import os
os.system("cls")

class User:
    def __init__(self, username):
        self.username = username
        self.friends = []
    def add_friend(self, friend):
        if friend not in self.friends:
            self.friends.append(friend)
            return True
        return False
    def remove_friend(self, friend):
        if friend in self.friends:
            self.friends.remove(friend)
            return True
        return False
    def list_friend(self):
        return self.friends
    def mutual_friend(self, other_user):
        boshqa = []
        for friend in self.friends:
            if friend in other_user.friends:
                boshqa.append(friend)
        return boshqa

u1 = User("Ali")
u2 = User("Vali")

print(u1.add_friend("Sami")) 
print(u1.add_friend("Vali")) 
print(u1.add_friend("Sami")) 

print(u2.add_friend("Ali")) 
print(u2.add_friend("Sami"))

print(u1.list_friend())   
print(u2.list_friend())    

print(u1.mutual_friend(u2)) 

print(u1.remove_friend("Vali")) 
print(u1.remove_friend("Botir"))
print(u1.list_friend())

    